#ifndef FILTER_H
#define FILTER_H

int *  filter( int * , int *, bool (*p) ( const int & ) );
#endif
